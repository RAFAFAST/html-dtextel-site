(() => {
  'use strict';

  const SELECTORS = {
    header: '[data-site-header]',
    nav: '[data-main-nav]',
    navToggle: '[data-nav-toggle]',
    dropdown: '[data-dropdown]',
    dropdownTrigger: '[data-dropdown-trigger]',
    reveal: '[data-reveal]',
    counter: '[data-counter]',
    faqItem: '[data-faq-item]',
    faqButton: '[data-faq-button]',
    slider: '[data-testimonial-slider]',
    needSelector: '[data-need-selector]',
    whatsapp: '[data-whatsapp-message]',
    scrollProgress: '[data-scroll-progress]'
  };

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isMobileNav = () => window.matchMedia('(max-width: 920px)').matches;

  const iconSvg = (name, className = 'icon') => {
    const icons = {
      phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.69 2.8a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.33 1.84.56 2.8.69A2 2 0 0 1 22 16.92z"/>',
      message: '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/>',
      arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
      arrowLeft: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
      chevronDown: '<path d="m6 9 6 6 6-6"/>',
      shield: '<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3z"/><path d="m9 12 2 2 4-4"/>',
      cloud: '<path d="M17.5 19H6a4 4 0 0 1-.8-7.92A6 6 0 0 1 16.7 9.1 5 5 0 0 1 17.5 19z"/>',
      network: '<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="16" y="16" width="6" height="6" rx="1"/><path d="M12 8v4M5 16v-2h14v2"/>',
      headset: '<path d="M4 14a8 8 0 0 1 16 0"/><path d="M18 19c0 1.7-1.3 3-3 3h-3"/><rect x="3" y="13" width="4" height="6" rx="2"/><rect x="17" y="13" width="4" height="6" rx="2"/>',
      globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 0 20M12 2a15.3 15.3 0 0 0 0 20"/>',
      server: '<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01M11 7h6M11 17h6"/>',
      chart: '<path d="M3 3v18h18"/><path d="m7 16 4-5 4 3 5-7"/>',
      users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
      check: '<path d="m20 6-11 11-5-5"/>',
      clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
      map: '<polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><path d="M9 3v15M15 6v15"/>',
      wifi: '<path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/>',
      search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
      lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
      menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
      close: '<path d="M18 6 6 18M6 6l12 12"/>',
      mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
      building: '<path d="M3 21h18M6 21V5l6-3 6 3v16M9 9h.01M9 13h.01M9 17h.01M15 9h.01M15 13h.01M15 17h.01"/>',
      spark: '<path d="m12 3-1.7 5.3L5 10l5.3 1.7L12 17l1.7-5.3L19 10l-5.3-1.7z"/><path d="m5 3-.7 2.3L2 6l2.3.7L5 9l.7-2.3L8 6l-2.3-.7zM19 16l-.7 2.3L16 19l2.3.7L19 22l.7-2.3L22 19l-2.3-.7z"/>',
      whatsapp: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8A8.5 8.5 0 0 1 12.5 20a8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8A8.5 8.5 0 0 1 8.7 3.9a8.38 8.38 0 0 1 3.8-.9h.5A8.48 8.48 0 0 1 21 11z"/><path d="M9.2 8.4c.2-.4.4-.4.7-.4h.4c.1 0 .3 0 .4.3l.8 1.8c.1.2.1.4 0 .5l-.6.7c-.1.1-.2.3 0 .5.5.9 1.2 1.6 2.1 2.1.2.1.4.1.5 0l.8-1c.2-.2.4-.2.6-.1l1.8.9c.2.1.3.2.3.4 0 .4-.2 1.3-.7 1.8-.5.5-1.2.8-2 .6-1.2-.2-2.7-.8-4.3-2.2-1.3-1.1-2.2-2.6-2.5-3.7-.3-1 .1-1.8.5-2.2z"/>',
      bolt: '<path d="m13 2-9 12h8l-1 8 9-12h-8z"/>',
      external: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>'
    };

    return `<svg class="${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.spark}</svg>`;
  };

  window.DlextelIcons = { svg: iconSvg };

  const initHeader = () => {
    const header = document.querySelector(SELECTORS.header);
    const nav = document.querySelector(SELECTORS.nav);
    const toggle = document.querySelector(SELECTORS.navToggle);
    const dropdowns = [...document.querySelectorAll(SELECTORS.dropdown)];

    const updateHeader = () => {
      if (header) header.classList.toggle('is-scrolled', window.scrollY > 8);
    };

    updateHeader();
    window.addEventListener('scroll', updateHeader, { passive: true });

    const closeDropdowns = (except = null) => {
      dropdowns.forEach((dropdown) => {
        if (dropdown === except) return;
        dropdown.classList.remove('is-open');
        const trigger = dropdown.querySelector(SELECTORS.dropdownTrigger);
        if (trigger) trigger.setAttribute('aria-expanded', 'false');
      });
    };

    const closeNav = () => {
      if (!nav || !toggle) return;
      nav.classList.remove('is-open');
      toggle.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('nav-open');
      closeDropdowns();
    };

    if (toggle && nav) {
      toggle.addEventListener('click', () => {
        const willOpen = !nav.classList.contains('is-open');
        nav.classList.toggle('is-open', willOpen);
        toggle.classList.toggle('is-open', willOpen);
        toggle.setAttribute('aria-expanded', String(willOpen));
        document.body.classList.toggle('nav-open', willOpen);
      });

      nav.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
          if (isMobileNav()) closeNav();
        });
      });
    }

    dropdowns.forEach((dropdown) => {
      const trigger = dropdown.querySelector(SELECTORS.dropdownTrigger);
      if (!trigger) return;
      trigger.addEventListener('click', (event) => {
        event.preventDefault();
        const willOpen = !dropdown.classList.contains('is-open');
        closeDropdowns(dropdown);
        dropdown.classList.toggle('is-open', willOpen);
        trigger.setAttribute('aria-expanded', String(willOpen));
      });
    });

    document.addEventListener('click', (event) => {
      if (!event.target.closest(SELECTORS.dropdown)) closeDropdowns();
      if (isMobileNav() && nav?.classList.contains('is-open') && !event.target.closest(SELECTORS.nav) && !event.target.closest(SELECTORS.navToggle)) {
        closeNav();
      }
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeNav();
    });

    window.addEventListener('resize', () => {
      if (!isMobileNav()) closeNav();
    });
  };

  const initScrollProgress = () => {
    const bar = document.querySelector(SELECTORS.scrollProgress);
    if (!bar) return;
    const update = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const value = max > 0 ? Math.min(100, (window.scrollY / max) * 100) : 0;
      bar.style.width = `${value}%`;
    };
    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
  };

  const initReveal = () => {
    const items = [...document.querySelectorAll(SELECTORS.reveal)];
    if (!items.length) return;
    if (prefersReducedMotion || !('IntersectionObserver' in window)) {
      items.forEach((item) => item.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -35px' });
    items.forEach((item) => observer.observe(item));
  };

  const initCounters = () => {
    const counters = [...document.querySelectorAll(SELECTORS.counter)];
    if (!counters.length) return;

    const animateCounter = (element) => {
      const target = Number(element.dataset.counter || 0);
      const suffix = element.dataset.suffix || '';
      const prefix = element.dataset.prefix || '';
      const duration = prefersReducedMotion ? 0 : Number(element.dataset.duration || 1400);
      const startTime = performance.now();

      const tick = (now) => {
        const progress = duration === 0 ? 1 : Math.min(1, (now - startTime) / duration);
        const eased = 1 - Math.pow(1 - progress, 3);
        const value = Math.round(target * eased);
        element.textContent = `${prefix}${value.toLocaleString('pt-BR')}${suffix}`;
        if (progress < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    };

    if (!('IntersectionObserver' in window)) {
      counters.forEach(animateCounter);
      return;
    }

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        animateCounter(entry.target);
        obs.unobserve(entry.target);
      });
    }, { threshold: 0.6 });
    counters.forEach((counter) => observer.observe(counter));
  };

  const initFaqs = () => {
    document.querySelectorAll(SELECTORS.faqItem).forEach((item) => {
      const button = item.querySelector(SELECTORS.faqButton);
      if (!button) return;
      button.addEventListener('click', () => {
        const open = item.classList.toggle('is-open');
        button.setAttribute('aria-expanded', String(open));
      });
    });
  };

  const initTestimonialSliders = () => {
    document.querySelectorAll(SELECTORS.slider).forEach((slider) => {
      const track = slider.querySelector('[data-slider-track]');
      const slides = [...slider.querySelectorAll('[data-slider-slide]')];
      const prev = slider.querySelector('[data-slider-prev]');
      const next = slider.querySelector('[data-slider-next]');
      const dotsWrap = slider.querySelector('[data-slider-dots]');
      if (!track || slides.length < 2) return;

      let index = 0;
      let timer = null;
      const dots = slides.map((_, dotIndex) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'slider-dot';
        button.setAttribute('aria-label', `Ir para depoimento ${dotIndex + 1}`);
        button.addEventListener('click', () => goTo(dotIndex, true));
        dotsWrap?.appendChild(button);
        return button;
      });

      const render = () => {
        track.style.transform = `translateX(-${index * 100}%)`;
        slides.forEach((slide, slideIndex) => {
          slide.setAttribute('aria-hidden', String(slideIndex !== index));
        });
        dots.forEach((dot, dotIndex) => dot.classList.toggle('is-active', dotIndex === index));
      };

      const start = () => {
        if (prefersReducedMotion) return;
        stop();
        timer = window.setInterval(() => goTo(index + 1), 6500);
      };

      const stop = () => {
        if (timer) window.clearInterval(timer);
      };

      function goTo(newIndex, restart = false) {
        index = (newIndex + slides.length) % slides.length;
        render();
        if (restart) start();
      }

      prev?.addEventListener('click', () => goTo(index - 1, true));
      next?.addEventListener('click', () => goTo(index + 1, true));
      slider.addEventListener('mouseenter', stop);
      slider.addEventListener('mouseleave', start);
      slider.addEventListener('focusin', stop);
      slider.addEventListener('focusout', start);

      let touchStartX = 0;
      slider.addEventListener('touchstart', (event) => {
        touchStartX = event.changedTouches[0].clientX;
        stop();
      }, { passive: true });
      slider.addEventListener('touchend', (event) => {
        const delta = event.changedTouches[0].clientX - touchStartX;
        if (Math.abs(delta) > 45) goTo(index + (delta < 0 ? 1 : -1));
        start();
      }, { passive: true });

      render();
      start();
    });
  };

  const initNeedSelectors = () => {
    document.querySelectorAll(SELECTORS.needSelector).forEach((selector) => {
      const tabs = [...selector.querySelectorAll('[data-need-tab]')];
      const panels = [...selector.querySelectorAll('[data-need-panel]')];
      if (!tabs.length || !panels.length) return;

      const activate = (id) => {
        tabs.forEach((tab) => {
          const active = tab.dataset.needTab === id;
          tab.classList.toggle('is-active', active);
          tab.setAttribute('aria-selected', String(active));
          tab.tabIndex = active ? 0 : -1;
        });
        panels.forEach((panel) => {
          const active = panel.dataset.needPanel === id;
          panel.classList.toggle('is-active', active);
          panel.hidden = !active;
        });
      };

      tabs.forEach((tab, tabIndex) => {
        tab.addEventListener('click', () => activate(tab.dataset.needTab));
        tab.addEventListener('keydown', (event) => {
          if (!['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;
          event.preventDefault();
          const direction = ['ArrowRight', 'ArrowDown'].includes(event.key) ? 1 : -1;
          const nextIndex = (tabIndex + direction + tabs.length) % tabs.length;
          tabs[nextIndex].focus();
          activate(tabs[nextIndex].dataset.needTab);
        });
      });
      activate(tabs.find((tab) => tab.classList.contains('is-active'))?.dataset.needTab || tabs[0].dataset.needTab);
    });
  };

  const initWhatsAppLinks = () => {
    document.querySelectorAll(SELECTORS.whatsapp).forEach((link) => {
      const message = link.dataset.whatsappMessage || 'Olá, conheci a D.lextel pelo site e gostaria de falar com um especialista.';
      const phone = link.dataset.whatsappPhone || '551139950800';
      link.href = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    });
  };

  const initNetworkCanvas = () => {
    const canvas = document.querySelector('[data-network-canvas]');
    if (!canvas || prefersReducedMotion) return;
    const context = canvas.getContext('2d');
    if (!context) return;

    let width = 0;
    let height = 0;
    let frame = null;
    let particles = [];
    const pointer = { x: null, y: null };

    const resize = () => {
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      const bounds = canvas.getBoundingClientRect();
      width = Math.max(1, bounds.width);
      height = Math.max(1, bounds.height);
      canvas.width = Math.floor(width * ratio);
      canvas.height = Math.floor(height * ratio);
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      const count = Math.min(75, Math.max(28, Math.floor(width / 24)));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - .5) * .2,
        vy: (Math.random() - .5) * .2,
        r: Math.random() * 1.4 + .4
      }));
    };

    const draw = () => {
      context.clearRect(0, 0, width, height);
      particles.forEach((particle, index) => {
        particle.x += particle.vx;
        particle.y += particle.vy;
        if (particle.x < 0 || particle.x > width) particle.vx *= -1;
        if (particle.y < 0 || particle.y > height) particle.vy *= -1;

        if (pointer.x !== null) {
          const dx = pointer.x - particle.x;
          const dy = pointer.y - particle.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < 130 && distance > 0) {
            particle.x -= dx * .0008;
            particle.y -= dy * .0008;
          }
        }

        context.beginPath();
        context.arc(particle.x, particle.y, particle.r, 0, Math.PI * 2);
        context.fillStyle = 'rgba(122, 199, 235, .48)';
        context.fill();

        for (let j = index + 1; j < particles.length; j += 1) {
          const other = particles[j];
          const dx = particle.x - other.x;
          const dy = particle.y - other.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance > 115) continue;
          context.beginPath();
          context.moveTo(particle.x, particle.y);
          context.lineTo(other.x, other.y);
          context.strokeStyle = `rgba(122, 199, 235, ${(.14 * (1 - distance / 115)).toFixed(3)})`;
          context.lineWidth = .6;
          context.stroke();
        }
      });
      frame = requestAnimationFrame(draw);
    };

    canvas.addEventListener('pointermove', (event) => {
      const bounds = canvas.getBoundingClientRect();
      pointer.x = event.clientX - bounds.left;
      pointer.y = event.clientY - bounds.top;
    }, { passive: true });
    canvas.addEventListener('pointerleave', () => {
      pointer.x = null;
      pointer.y = null;
    });

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        if (!frame) draw();
      } else if (frame) {
        cancelAnimationFrame(frame);
        frame = null;
      }
    });
    observer.observe(canvas);
    resize();
    window.addEventListener('resize', resize);
  };

  const initSmoothAnchors = () => {
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener('click', (event) => {
        const id = anchor.getAttribute('href');
        if (!id || id === '#') return;
        const target = document.querySelector(id);
        if (!target) return;
        event.preventDefault();
        target.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'start' });
        history.replaceState(null, '', id);
      });
    });
  };

  const initCurrentYear = () => {
    document.querySelectorAll('[data-current-year]').forEach((element) => {
      element.textContent = String(new Date().getFullYear());
    });
  };

  const initExternalLinks = () => {
    document.querySelectorAll('a[href^="http"]').forEach((link) => {
      const url = new URL(link.href, window.location.href);
      if (url.hostname !== window.location.hostname) {
        link.rel = link.rel || 'noopener noreferrer';
      }
    });
  };

  document.documentElement.classList.remove('no-js');
  initHeader();
  initScrollProgress();
  initReveal();
  initCounters();
  initFaqs();
  initTestimonialSliders();
  initNeedSelectors();
  initWhatsAppLinks();
  initNetworkCanvas();
  initSmoothAnchors();
  initCurrentYear();
  initExternalLinks();
})();
