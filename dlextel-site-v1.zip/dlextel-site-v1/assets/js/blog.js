(() => {
  'use strict';

  const grid = document.querySelector('[data-blog-grid]');
  if (!grid) return;

  const searchInput = document.querySelector('[data-blog-search]');
  const searchButton = document.querySelector('[data-blog-search-button]');
  const status = document.querySelector('[data-blog-status]');
  const prevButton = document.querySelector('[data-blog-prev]');
  const nextButton = document.querySelector('[data-blog-next]');
  const pageLabel = document.querySelector('[data-blog-page]');
  const API_BASE = 'https://dlextel.com.br/wp-json/wp/v2/posts';
  const PAGE_SIZE = 9;

  let page = 1;
  let pages = 1;
  let currentSearch = '';
  let requestController = null;

  const fallbackPosts = [
    {
      title: 'Omnichannel: o que é, como funciona e exemplos práticos',
      url: 'https://dlextel.com.br/omnichannel-o-que-e/',
      date: '16 de abril de 2025',
      category: 'Omnichannel',
      excerpt: 'Entenda como integrar canais, preservar o contexto do cliente e criar uma experiência de atendimento mais fluida.',
      image: ''
    },
    {
      title: 'Redução de custos em telecomunicações: estratégias eficientes',
      url: 'https://dlextel.com.br/reducao-de-custos/',
      date: '14 de abril de 2025',
      category: 'Gestão de telecom',
      excerpt: 'Boas práticas para revisar contratos, modernizar a telefonia e ganhar eficiência sem comprometer a operação.',
      image: ''
    },
    {
      title: 'O que é VoIP? Entenda a tecnologia de telefonia pela internet',
      url: 'https://dlextel.com.br/o-que-e-voip/',
      date: '11 de abril de 2025',
      category: 'Telefonia VoIP',
      excerpt: 'Um guia para entender o funcionamento da voz sobre IP, seus benefícios e aplicações no ambiente corporativo.',
      image: ''
    },
    {
      title: 'Sistema de telefonia: passo a passo para escolher o melhor',
      url: 'https://dlextel.com.br/sistema-de-telefonia-escolha-melhor/',
      date: 'Conteúdo D.lextel',
      category: 'PABX',
      excerpt: 'Veja os critérios mais importantes para comparar soluções de telefonia e planejar a evolução da comunicação da empresa.',
      image: ''
    },
    {
      title: 'URA Reversa: o que é, como funciona e benefícios para empresas',
      url: 'https://dlextel.com.br/ura-reversa/',
      date: 'Conteúdo D.lextel',
      category: 'Atendimento',
      excerpt: 'Conheça a automação que inicia contatos em escala, confirma dados e direciona chamadas para equipes especializadas.',
      image: ''
    },
    {
      title: 'Telefonia empresarial: mobilidade, gestão e produtividade',
      url: 'https://dlextel.com.br/blog/',
      date: 'Conteúdo D.lextel',
      category: 'Telefonia IP',
      excerpt: 'Conteúdos sobre ramais virtuais, softphone, filas, gravações e recursos que ajudam empresas a atender melhor.',
      image: ''
    }
  ];

  const escapeHtml = (value) => String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  const decodeHtml = (html) => {
    const element = document.createElement('textarea');
    element.innerHTML = html || '';
    return element.value;
  };

  const stripHtml = (html) => {
    const element = document.createElement('div');
    element.innerHTML = html || '';
    return (element.textContent || element.innerText || '').replace(/\s+/g, ' ').trim();
  };

  const formatDate = (dateString) => {
    try {
      return new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }).format(new Date(dateString));
    } catch (_) {
      return 'Conteúdo D.lextel';
    }
  };

  const getFeaturedImage = (post) => {
    const media = post?._embedded?.['wp:featuredmedia']?.[0];
    return media?.media_details?.sizes?.medium_large?.source_url
      || media?.media_details?.sizes?.large?.source_url
      || media?.source_url
      || '';
  };

  const getCategory = (post) => {
    const terms = post?._embedded?.['wp:term']?.flat?.() || [];
    const category = terms.find((term) => term.taxonomy === 'category');
    return category?.name || 'Telecomunicações';
  };

  const normalizePost = (post) => ({
    title: decodeHtml(post.title?.rendered || 'Conteúdo D.lextel'),
    url: post.link || 'https://dlextel.com.br/blog/',
    date: formatDate(post.date),
    category: getCategory(post),
    excerpt: stripHtml(post.excerpt?.rendered || '').slice(0, 220),
    image: getFeaturedImage(post)
  });

  const cardTemplate = (post) => `
    <article class="blog-card" data-reveal>
      <a class="blog-card__media" href="${escapeHtml(post.url)}" target="_blank" rel="noopener noreferrer" aria-label="Ler: ${escapeHtml(post.title)}">
        ${post.image
          ? `<img src="${escapeHtml(post.image)}" alt="" loading="lazy" decoding="async">`
          : `<span class="blog-card__placeholder">
              <span>
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                Conteúdo sobre comunicação corporativa
              </span>
            </span>`}
      </a>
      <div class="blog-card__body">
        <div class="blog-card__meta">
          <span>${escapeHtml(post.category)}</span>
          <span>•</span>
          <time>${escapeHtml(post.date)}</time>
        </div>
        <h3><a href="${escapeHtml(post.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(post.title)}</a></h3>
        <p>${escapeHtml(post.excerpt || 'Acesse o artigo completo no blog da D.lextel.')}</p>
        <a class="btn btn--link" href="${escapeHtml(post.url)}" target="_blank" rel="noopener noreferrer">
          Ler artigo
          <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </a>
      </div>
    </article>
  `;

  const renderSkeletons = () => {
    grid.innerHTML = Array.from({ length: 6 }, () => `
      <article class="blog-card" aria-hidden="true">
        <div class="blog-card__media skeleton"></div>
        <div class="blog-card__body">
          <div class="skeleton" style="height:12px;width:42%;border-radius:6px;margin-bottom:14px"></div>
          <div class="skeleton" style="height:24px;width:92%;border-radius:6px;margin-bottom:10px"></div>
          <div class="skeleton" style="height:16px;width:100%;border-radius:6px;margin-bottom:8px"></div>
          <div class="skeleton" style="height:16px;width:78%;border-radius:6px"></div>
        </div>
      </article>
    `).join('');
  };

  const updatePagination = () => {
    if (prevButton) prevButton.disabled = page <= 1;
    if (nextButton) nextButton.disabled = page >= pages;
    if (pageLabel) pageLabel.textContent = `Página ${page} de ${pages}`;
  };

  const render = (posts, message = '') => {
    grid.innerHTML = posts.map(cardTemplate).join('');
    if (status) status.textContent = message || `${posts.length} conteúdo${posts.length === 1 ? '' : 's'} carregado${posts.length === 1 ? '' : 's'}.`;
    updatePagination();
    grid.querySelectorAll('[data-reveal]').forEach((card) => requestAnimationFrame(() => card.classList.add('is-visible')));
  };

  const filteredFallback = () => {
    if (!currentSearch) return fallbackPosts;
    const query = currentSearch.toLocaleLowerCase('pt-BR');
    return fallbackPosts.filter((post) => `${post.title} ${post.category} ${post.excerpt}`.toLocaleLowerCase('pt-BR').includes(query));
  };

  const renderFallback = (reason = '') => {
    const posts = filteredFallback();
    page = 1;
    pages = 1;
    render(posts, posts.length
      ? `Exibindo uma seleção do blog atual${reason ? ' enquanto a integração em tempo real fica indisponível' : ''}.`
      : 'Nenhum conteúdo da seleção corresponde à pesquisa.');
  };

  const loadPosts = async () => {
    if (requestController) requestController.abort();
    requestController = new AbortController();
    renderSkeletons();
    if (status) status.textContent = 'Carregando artigos do WordPress...';

    const params = new URLSearchParams({
      _embed: '1',
      per_page: String(PAGE_SIZE),
      page: String(page)
    });
    if (currentSearch) params.set('search', currentSearch);

    try {
      const response = await fetch(`${API_BASE}?${params.toString()}`, {
        signal: requestController.signal,
        headers: { Accept: 'application/json' }
      });
      if (!response.ok) throw new Error(`WordPress REST retornou ${response.status}`);
      const data = await response.json();
      pages = Math.max(1, Number(response.headers.get('X-WP-TotalPages') || 1));
      const posts = Array.isArray(data) ? data.map(normalizePost) : [];
      if (!posts.length) {
        render([], currentSearch ? 'Nenhum artigo encontrado para essa pesquisa.' : 'Nenhum artigo disponível no momento.');
        return;
      }
      render(posts, `Conteúdo sincronizado com o WordPress da D.lextel.`);
    } catch (error) {
      if (error.name === 'AbortError') return;
      console.warn('Falha ao carregar o WordPress REST; usando seleção local.', error);
      renderFallback('api');
    }
  };

  const search = () => {
    currentSearch = searchInput?.value.trim() || '';
    page = 1;
    loadPosts();
  };

  searchButton?.addEventListener('click', search);
  searchInput?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      search();
    }
  });

  prevButton?.addEventListener('click', () => {
    if (page <= 1) return;
    page -= 1;
    loadPosts();
    grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  nextButton?.addEventListener('click', () => {
    if (page >= pages) return;
    page += 1;
    loadPosts();
    grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  loadPosts();
})();
