(() => {
  'use strict';

  const form = document.querySelector('[data-contact-form]');
  if (!form) return;

  const steps = [...form.querySelectorAll('[data-form-step]')];
  const nextButtons = [...form.querySelectorAll('[data-form-next]')];
  const prevButtons = [...form.querySelectorAll('[data-form-prev]')];
  const progress = form.closest('.wizard')?.querySelector('[data-form-progress]');
  const stepLabel = form.closest('.wizard')?.querySelector('[data-form-step-label]');
  const summary = form.querySelector('[data-form-summary]');
  const success = form.closest('.wizard')?.querySelector('[data-form-success]');
  const wizardBody = form.closest('.wizard')?.querySelector('[data-wizard-body]');
  const messageField = form.querySelector('[name="mensagem"]');
  const charCount = form.querySelector('[data-char-count]');
  const storageKey = 'dlextel-contact-draft-v1';
  let currentStep = 0;

  const labels = ['Sua necessidade', 'Sobre sua empresa', 'Seus dados'];

  const getSelectedService = () => {
    const checked = form.querySelector('[name="servico"]:checked');
    return checked?.value || '';
  };

  const getData = () => Object.fromEntries(new FormData(form).entries());

  const saveDraft = () => {
    try {
      const data = getData();
      delete data.website;
      localStorage.setItem(storageKey, JSON.stringify(data));
    } catch (_) {
      // Storage may be unavailable in private mode. The form still works.
    }
  };

  const restoreDraft = () => {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || '{}');
      Object.entries(saved).forEach(([name, value]) => {
        const field = form.elements.namedItem(name);
        if (!field) return;
        if (field instanceof RadioNodeList) {
          [...field].forEach((radio) => {
            radio.checked = radio.value === value;
          });
        } else {
          field.value = value;
        }
      });
    } catch (_) {
      // Ignore malformed drafts.
    }
  };

  const formatPhone = (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    if (digits.length <= 2) return digits;
    if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
    if (digits.length <= 10) return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  };

  const clearErrors = (scope) => {
    scope.querySelectorAll('[aria-invalid="true"]').forEach((field) => field.removeAttribute('aria-invalid'));
    scope.querySelectorAll('[data-field-error]').forEach((error) => {
      error.textContent = '';
    });
  };

  const setError = (field, message) => {
    field.setAttribute('aria-invalid', 'true');
    const group = field.closest('.form-group, .choice-grid, .form-consent');
    const target = group?.querySelector('[data-field-error]');
    if (target) target.textContent = message;
  };

  const validateStep = (index) => {
    const step = steps[index];
    if (!step) return true;
    clearErrors(step);
    let valid = true;

    if (index === 0) {
      const checked = form.querySelector('[name="servico"]:checked');
      if (!checked) {
        const first = form.querySelector('[name="servico"]');
        if (first) setError(first, 'Selecione a solução que mais se aproxima da sua necessidade.');
        valid = false;
      }
    }

    step.querySelectorAll('[required]').forEach((field) => {
      if (field.type === 'radio' || field.type === 'checkbox') return;
      const value = field.value.trim();
      if (!value) {
        setError(field, 'Preencha este campo.');
        valid = false;
        return;
      }
      if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        setError(field, 'Informe um e-mail válido.');
        valid = false;
      }
      if (field.name === 'telefone' && value.replace(/\D/g, '').length < 10) {
        setError(field, 'Informe um telefone com DDD.');
        valid = false;
      }
    });

    if (index === 2) {
      const consent = form.querySelector('[name="consentimento"]');
      if (consent && !consent.checked) {
        setError(consent, 'É necessário autorizar o contato para continuar.');
        valid = false;
      }
    }

    if (!valid) {
      const firstInvalid = step.querySelector('[aria-invalid="true"]');
      firstInvalid?.focus();
    }
    return valid;
  };

  const renderSummary = () => {
    if (!summary) return;
    const data = getData();
    const rows = [
      ['Solução', data.servico || 'Não informado'],
      ['Objetivo', data.objetivo || 'Não informado'],
      ['Empresa', data.empresa || 'Não informado'],
      ['Porte', data.porte || 'Não informado'],
      ['Nome', data.nome || 'Não informado'],
      ['Contato', `${data.telefone || ''}${data.email ? ` · ${data.email}` : ''}`]
    ];
    summary.innerHTML = rows.map(([label, value]) => `
      <div class="form-summary__row">
        <strong>${escapeHtml(label)}</strong>
        <span>${escapeHtml(value)}</span>
      </div>
    `).join('');
  };

  const escapeHtml = (value) => String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  const goToStep = (index, { scroll = true, focus = true } = {}) => {
    currentStep = Math.max(0, Math.min(steps.length - 1, index));
    steps.forEach((step, stepIndex) => {
      const active = stepIndex === currentStep;
      step.classList.toggle('is-active', active);
      step.hidden = !active;
    });
    if (progress) progress.style.width = `${((currentStep + 1) / steps.length) * 100}%`;
    if (stepLabel) stepLabel.textContent = `Etapa ${currentStep + 1} de ${steps.length} · ${labels[currentStep] || ''}`;
    if (currentStep === steps.length - 1) renderSummary();
    const heading = steps[currentStep]?.querySelector('h2');
    if (focus && heading) {
      heading.setAttribute('tabindex', '-1');
      heading.focus({ preventScroll: true });
    }
    if (scroll) form.closest('.wizard')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const buildWhatsAppMessage = (data) => {
    const lines = [
      'Olá, vim pelo novo site da D.lextel e gostaria de falar com um especialista.',
      '',
      `Solução de interesse: ${data.servico || 'Não informado'}`,
      `Objetivo: ${data.objetivo || 'Não informado'}`,
      `Empresa: ${data.empresa || 'Não informado'}`,
      `Porte/equipe: ${data.porte || 'Não informado'}`,
      `Nome: ${data.nome || 'Não informado'}`,
      `Telefone: ${data.telefone || 'Não informado'}`,
      `E-mail: ${data.email || 'Não informado'}`,
      '',
      `Mensagem: ${data.mensagem || 'Gostaria de receber uma orientação inicial.'}`
    ];
    return lines.join('\n');
  };

  const submitToEndpoint = async (data) => {
    const endpoint = window.DLEXTEL_FORM_ENDPOINT;
    if (!endpoint) return false;
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error(`Falha no envio (${response.status})`);
    return true;
  };

  nextButtons.forEach((button) => {
    button.addEventListener('click', () => {
      if (!validateStep(currentStep)) return;
      saveDraft();
      goToStep(currentStep + 1);
    });
  });

  prevButtons.forEach((button) => {
    button.addEventListener('click', () => goToStep(currentStep - 1));
  });

  form.addEventListener('input', (event) => {
    const field = event.target;
    if (field.name === 'telefone') field.value = formatPhone(field.value);
    if (field === messageField && charCount) charCount.textContent = `${field.value.length}/600`;
    if (field.hasAttribute('aria-invalid')) {
      field.removeAttribute('aria-invalid');
      const group = field.closest('.form-group, .choice-grid, .form-consent');
      const target = group?.querySelector('[data-field-error]');
      if (target) target.textContent = '';
    }
    saveDraft();
  });

  form.addEventListener('change', saveDraft);

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!validateStep(currentStep)) return;
    const data = getData();
    if (data.website) return;

    const submitButton = form.querySelector('[type="submit"]');
    const originalText = submitButton?.innerHTML;
    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = 'Preparando atendimento...';
    }

    try {
      const sent = await submitToEndpoint(data);
      if (!sent) {
        const whatsappMessage = buildWhatsAppMessage(data);
        const url = `https://wa.me/551139950800?text=${encodeURIComponent(whatsappMessage)}`;
        window.open(url, '_blank', 'noopener,noreferrer');
      }

      try { localStorage.removeItem(storageKey); } catch (_) { /* ignore */ }
      if (wizardBody) wizardBody.hidden = true;
      if (success) success.classList.add('is-visible');
      success?.querySelector('h2')?.focus();
    } catch (error) {
      const globalError = form.querySelector('[data-form-global-error]');
      if (globalError) globalError.textContent = 'Não foi possível enviar automaticamente. Use o botão do WhatsApp ou ligue para (11) 3995-0800.';
      console.error(error);
    } finally {
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.innerHTML = originalText;
      }
    }
  });

  restoreDraft();
  if (messageField && charCount) charCount.textContent = `${messageField.value.length}/600`;
  goToStep(0, { scroll: false, focus: false });
})();
